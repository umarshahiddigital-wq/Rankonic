import Link from "next/link";
import { FinalCta, JsonLd } from "../../components/ui";
import { site } from "../../content/site";

export const metadata = {
  title: "About Rankonic Digital | SEO Agency Partner for Link Building",
  description: "Meet Rankonic Digital and founder Umar Shahid. Learn how we approach guest posting, link building, Digital PR and AI-search visibility for SEO agencies and SaaS companies.",
  alternates: { canonical: "/about" },
  openGraph: { title: "About Rankonic Digital", description: "A link-building and Digital PR partner for SEO agencies and SaaS companies.", url: "/about" },
};

export default function About() {
  return (
    <>
      <section className="hero"><div className="wrap">
        <div>
          <span className="eyebrow">About us</span>
          <h1>About Rankonic Digital</h1>
          <p className="lead">Rankonic Digital is a digital marketing agency focused on guest posting, link building and Digital PR for SEO agencies and SaaS companies.</p>
          <p>Founded by Umar Shahid, the agency is built around practical execution, honest communication and relevance over vanity metrics.</p>
          <Link href="/contact" className="btn p">Get in Touch</Link>
        </div>
        <div>
          {/* Replace /public/founder-placeholder.png with your real photo (4:5 portrait). Keep the same file name or update src below. */}
          <img className="ph" src="/founder-placeholder.png" alt="Placeholder for a photo of founder Umar Shahid" width="800" height="1000" />
          <p className="small" style={{ marginTop: 10 }}><strong>{site.founder}</strong>, Founder</p>
        </div>
      </div></section>

      <section className="s"><div className="wrap split" style={{ alignItems: "start" }}>
        <div><span className="eyebrow">From the founder</span><h2>Why Rankonic Digital exists</h2></div>
        <div>
          <p>I started Rankonic Digital to give SEO agencies and software companies a link-building partner they can rely on. The work covers guest posting, link building, Digital PR, SaaS authority development and visibility in AI-assisted search.</p>
          <p>My approach is simple: choose relevant publishers, communicate clearly, and be honest about what any campaign can and can't achieve.</p>
          <p><strong>Umar Shahid</strong><br />Founder, Rankonic Digital</p>
        </div>
      </div></section>

      <section className="s alt"><div className="wrap">
        <div className="head"><span className="eyebrow">Our approach</span><h2>How we work</h2></div>
        <div className="grid g3">
          {[["Relevance before vanity metrics", "We look at topical fit and editorial quality before domain scores."],
            ["Understanding your goals", "We start with your clients, markets and target pages, not a template."],
            ["Practical execution", "Clear scope, steady outreach and straightforward handovers."],
            ["Clear communication", "You'll always know what's happening and what we need from you."],
            ["Long-term SEO thinking", "Links should support a strategy that still makes sense next year."],
            ["Honest reporting", "We share what's been done and what's still open, and we set realistic expectations."]].map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}
        </div>
      </div></section>

      <section className="s"><div className="wrap">
        <div className="head"><span className="eyebrow">Who we help</span><h2>The teams we're built for</h2></div>
        <div className="grid g2">
          {[["SEO agencies", "Looking for a dependable execution partner for link building and Digital PR."],
            ["Digital marketing agencies", "Needing extra link-building capacity without hiring in-house."],
            ["SaaS businesses", "Seeking relevant authority-building opportunities in their industry."],
            ["B2B and AI companies", "Interested in broader organic and AI-search visibility."]].map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}
        </div>
      </div></section>

      <section className="s alt"><div className="wrap">
        <div className="head"><span className="eyebrow">Values</span><h2>What we stand for</h2></div>
        <div className="grid g3">
          {[["Relevance", "The right site for the right audience."], ["Transparency", "Clear scope, honest limits and open reporting."], ["Collaboration", "We work as an extension of your team."], ["Consistency", "Reliable follow-through from start to finish."], ["Continuous learning", "Search and AI discovery keep changing, and so do we."]].map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}
        </div>
        <p style={{ marginTop: 28 }}>See what we offer on our <Link href="/services">services page</Link>.</p>
      </div></section>
      <FinalCta />
      <JsonLd data={{ "@context": "https://schema.org", "@type": "Person", name: site.founder, jobTitle: "Founder", worksFor: { "@type": "Organization", name: site.name, url: site.url } }} />
    </>
  );
}
