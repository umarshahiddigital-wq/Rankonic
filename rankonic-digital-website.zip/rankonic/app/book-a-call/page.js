import CalendlyEmbed from "../../components/CalendlyEmbed";
import { site, whatsappUrl, calendlyReady } from "../../content/site";

export const metadata = {
  title: "Book an SEO Consultation Call | Rankonic Digital",
  description: "Book an introductory call with Rankonic Digital to discuss your link-building, Digital PR or agency partnership requirements.",
  alternates: { canonical: "/book-a-call" },
  openGraph: { title: "Book a Call with Rankonic Digital", description: "An introductory discussion about your SEO and link-building goals.", url: "/book-a-call" },
};

export default function Book() {
  return (
    <section className="hero"><div className="wrap" style={{ alignItems: "start" }}>
      <div>
        <span className="eyebrow">Book a call</span>
        <h1>Let's Discuss Your SEO and Link-Building Goals</h1>
        <p className="lead">An introductory call is a chance to talk through your business, target market and service requirements, and to see whether working together makes sense.</p>
        <ul className="ticks">
          <li>Your goals, clients and target markets</li>
          <li>Which services might be relevant</li>
          <li>How a partnership or project could be structured</li>
        </ul>
        <p className="note">This is an introductory conversation. We don't promise specific business outcomes.</p>
      </div>
      <div>
        {calendlyReady ? <CalendlyEmbed url={site.calendlyUrl} /> : (
          <div className="card">
            <h3>Online booking is coming soon</h3>
            <p>In the meantime, send us a message and we'll arrange a time that suits you.</p>
            <div className="row">
              <a className="btn p" href={`mailto:${site.email}?subject=Call%20request`}>Email Us</a>
              <a className="btn s" href={whatsappUrl} target="_blank" rel="noopener noreferrer">WhatsApp</a>
            </div>
          </div>
        )}
      </div>
    </div></section>
  );
}
