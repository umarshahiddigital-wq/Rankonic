import "./globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { JsonLd } from "../components/ui";
import { site } from "../content/site";

export const metadata = {
  metadataBase: new URL(site.url),
  title: { default: "Rankonic Digital | Link Building and Digital PR for SEO Agencies", template: "%s" },
  description: "Guest posting, link building and Digital PR for SEO agencies and SaaS companies.",
  openGraph: { siteName: "Rankonic Digital", type: "website", images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Rankonic Digital logo" }] },
  twitter: { card: "summary_large_image", images: ["/og-image.png"] },
};
export const viewport = { themeColor: "#030b1b" };

export default function RootLayout({ children }) {
  const org = { "@context": "https://schema.org", "@type": "ProfessionalService", name: site.name, url: site.url,
    logo: `${site.url}/logo-full.png`, image: `${site.url}/og-image.png`, email: site.email, telephone: `+${site.whatsappIntl}`,
    description: "Guest posting, link building, Digital PR and AI-search visibility support for SEO agencies and SaaS companies.",
    founder: { "@type": "Person", name: site.founder } };
  return (
    <html lang="en">
      <body>
        <a href="#main" className="skip">Skip to content</a>
        <Header />
        <main id="main">{children}</main>
        <Footer />
        <JsonLd data={org} />
      </body>
    </html>
  );
}
