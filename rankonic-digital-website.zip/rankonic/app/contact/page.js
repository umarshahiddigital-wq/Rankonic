import Link from "next/link";
import ContactForm from "../../components/ContactForm";
import { site, whatsappUrl } from "../../content/site";

export const metadata = {
  title: "Contact Rankonic Digital | Link-Building & Digital PR Inquiries",
  description: "Send your link-building, guest posting, Digital PR or agency partnership inquiry to Rankonic Digital by form, email or WhatsApp.",
  alternates: { canonical: "/contact" },
  openGraph: { title: "Contact Rankonic Digital", description: "Tell us about your link-building or Digital PR requirements.", url: "/contact" },
};

export default function Contact() {
  return (
    <section className="hero"><div className="wrap" style={{ alignItems: "start" }}>
      <div>
        <span className="eyebrow">Contact</span>
        <h1>Contact Rankonic Digital</h1>
        <p className="lead">Tell us what you need. We'll read your message and reply with an honest view of how we can help.</p>
        <div className="card" style={{ marginBottom: 16 }}><h3>Email</h3><a href={`mailto:${site.email}`}>{site.email}</a></div>
        <div className="card" style={{ marginBottom: 16 }}><h3>WhatsApp</h3>
          <p style={{ marginBottom: 12 }}>{site.whatsappDisplay}</p>
          <a className="btn p sm" href={whatsappUrl} target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></div>
        <div className="card"><h3>Prefer a call?</h3><p>You can <Link href="/book-a-call">book an introductory call</Link> to talk through your requirements.</p></div>
      </div>
      <div className="panel"><h2 style={{ fontSize: "1.5rem" }}>Send an inquiry</h2><ContactForm /></div>
    </div></section>
  );
}
