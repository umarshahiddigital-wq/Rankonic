import { site } from "../content/site";
export default function sitemap() {
  return ["", "/services", "/about", "/contact", "/book-a-call", "/privacy"].map((p) => ({ url: `${site.url}${p}`, changeFrequency: "monthly", priority: p === "" ? 1 : 0.7 }));
}
