import { site } from "../../content/site";
export const metadata = { title: "Privacy Policy | Rankonic Digital", description: "How Rankonic Digital handles information submitted through its website contact form.", alternates: { canonical: "/privacy" } };
export default function Privacy() {
  return (
    <section className="s"><div className="wrap" style={{ maxWidth: 780 }}>
      <h1>Privacy Policy</h1>
      <p className="note">Draft for review. This policy has not been reviewed by a lawyer. Please have it checked before launch, especially if you serve clients in the UK, EU or other regulated regions.</p>
      <h2>What we collect</h2>
      <p>When you use our contact form, we collect your name, email address, company or website, chosen service, optional budget range and the message you write. If you contact us by email or WhatsApp, we receive the details you choose to share.</p>
      <h2>How we use it</h2>
      <p>We use this information only to respond to your inquiry and discuss possible work together. We do not sell your information.</p>
      <h2>Who processes it</h2>
      <p>Form submissions are delivered to us by email through an email-delivery service (Resend). Calendly, if enabled, loads only when you choose to open the booking calendar and has its own privacy policy.</p>
      <h2>Retention and your rights</h2>
      <p>We keep inquiry emails as long as needed to respond and keep reasonable business records. You can ask us to access or delete your information by emailing {site.email}.</p>
      <h2>Analytics and cookies</h2>
      <p>This website does not currently use advertising trackers or analytics. If that changes, this policy will be updated.</p>
      <h2>Contact</h2>
      <p>Questions about this policy: {site.email}.</p>
    </div></section>
  );
}
