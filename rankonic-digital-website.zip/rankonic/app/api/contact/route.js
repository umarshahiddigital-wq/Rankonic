import { serviceOptions, budgetOptions } from "../../../content/site";

const hits = new Map(); // simple in-memory limiter: 5 requests / 10 min / IP (best effort on serverless hosting)
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const clean = (s, max) => String(s ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
const json = (body, status = 200) => Response.json(body, { status });

export async function POST(req) {
  const ip = (req.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim();
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 600000);
  if (recent.length >= 5) return json({ ok: false, error: "Too many requests. Please try again later." }, 429);
  hits.set(ip, [...recent, now]);

  let b;
  try { b = await req.json(); } catch { return json({ ok: false, error: "Invalid request." }, 400); }
  if (b.hp) return json({ ok: true }); // honeypot: silently accept bots, send nothing

  const d = { name: clean(b.name, 100), email: clean(b.email, 150), company: clean(b.company, 150),
    service: clean(b.service, 80), budget: clean(b.budget, 40) || "Not sure yet", message: String(b.message ?? "").trim().slice(0, 3000) };
  if (d.name.length < 2 || !emailRe.test(d.email) || d.company.length < 2 || !serviceOptions.includes(d.service) ||
      !budgetOptions.includes(d.budget) || d.message.length < 20)
    return json({ ok: false, error: "Please check the form fields and try again." }, 400);

  const key = process.env.RESEND_API_KEY;
  if (!key) return json({ ok: false, error: "Email delivery is not configured yet." }, 503);

  const text = `New inquiry from rankonicdigital website\n\nName: ${d.name}\nEmail: ${d.email}\nCompany/website: ${d.company}\nService: ${d.service}\nBudget: ${d.budget}\n\nRequirements:\n${d.message}`;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CONTACT_FROM_EMAIL || "Rankonic Digital <onboarding@resend.dev>",
        to: [process.env.CONTACT_TO_EMAIL || "umarshahid.digital@gmail.com"],
        reply_to: d.email, subject: `New inquiry: ${d.service} (${d.name})`, text,
      }),
    });
    if (!r.ok) return json({ ok: false, error: "The email service rejected the message." }, 502);
    return json({ ok: true });
  } catch { return json({ ok: false, error: "Could not reach the email service." }, 502); }
}
