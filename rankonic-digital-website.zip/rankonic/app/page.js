import Link from "next/link";
import { FinalCta, Faq, JsonLd } from "../components/ui";

export const metadata = {
  title: "Guest Posting & Link Building Services for SEO Agencies | Rankonic Digital",
  description: "Rankonic Digital is a link-building and Digital PR partner for SEO agencies and SaaS companies. Relevant guest posting, outreach and AI-search support, with honest communication.",
  alternates: { canonical: "/" },
  openGraph: { title: "Rankonic Digital | Link Building and Digital PR Partner", description: "Relevant guest posting, link building and Digital PR for SEO agencies and SaaS companies.", url: "/" },
};

const faqs = [
  ["What types of link-building services do you offer?", "We offer guest posting and link building, Digital PR, link building for SaaS companies, and support for AI SEO and LLM visibility. Each engagement is scoped around the client's niche, target pages and the publishers that make sense for them."],
  ["Do you work with SEO agencies?", "Yes. SEO agencies are our main audience. We can act as an execution partner for publisher research, outreach and placement coordination, so your team can stay focused on strategy and client management."],
  ["Can you support SaaS companies?", "Yes. We support B2B SaaS and AI companies with relevant link-building and Digital PR that fits alongside their wider SEO and content work."],
  ["Do you offer white-label link-building support?", "Where it suits both sides, yes. We can work behind the scenes and respect your relationship with your own clients. We'll agree how reporting and communication should work before we start."],
  ["How do you assess publisher relevance?", "We look at topical fit with the client's niche and audience, the quality of the site's editorial content, how natural a link would be in context, and the publisher's requirements. Authority metrics are one input, not the deciding factor."],
  ["Can you work with international clients?", "Yes. Rankonic Digital is set up to work with agencies and businesses in the United States, United Kingdom, Canada, Europe and other markets. We communicate by email and WhatsApp, and can arrange calls."],
  ["Do you guarantee Google rankings?", "No. Nobody can responsibly guarantee Google rankings, traffic or AI-search citations. Search engines weigh many factors outside any agency's control. We focus on doing the work properly and reporting honestly."],
  ["How can I discuss pricing and project requirements?", "Pricing depends on the target market, publisher criteria, campaign requirements and agreed deliverables. Send us your requirements through the contact page and we'll put together a tailored proposal."],
  ["Do you support AI-search visibility?", "Yes, as a complement to conventional SEO. We help improve content clarity, topical authority and discoverability. We can't control or guarantee what AI assistants cite or recommend."],
];

const principles = [
  ["Relevance over raw metrics", "A link from a topically relevant site usually serves a client better than one chosen only for a high domain score."],
  ["Publisher quality and fit", "We look at the publication's editorial standards, audience and content before suggesting it."],
  ["Links that support a strategy", "Backlinks work best when tied to clear target pages and a sensible wider SEO plan."],
  ["Realistic expectations", "We explain what is and isn't in our control, and we don't promise rankings or traffic."],
  ["Dependable coordination", "Clear scope, clear communication and steady follow-through, so agencies aren't left chasing updates."],
];

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="wrap">
          <div>
            <span className="eyebrow">For SEO agencies and SaaS teams</span>
            <h1>Reliable Link Building and Digital PR for SEO Agencies and SaaS Companies</h1>
            <p className="lead">Rankonic Digital plans and coordinates relevant guest posting, link-building and Digital PR campaigns. You get dependable execution without managing publisher research and outreach yourself.</p>
            <div className="row">
              <Link href="/contact" className="btn p">Discuss Your Requirements</Link>
              <Link href="/services" className="btn s">Explore Our Services</Link>
            </div>
          </div>
          <div className="panel"><img src="/logo-full.png" alt="Rankonic Digital logo" width="900" height="696" style={{ margin: "0 auto" }} /></div>
        </div>
      </section>

      <section className="s">
        <div className="wrap">
          <div className="head"><span className="eyebrow">Our approach</span><h2>How we think about link building</h2>
            <p>These are the principles we work by. They describe how we approach every campaign, not results we've already delivered.</p></div>
          <div className="grid g3">
            {principles.map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}
          </div>
        </div>
      </section>

      <section className="s alt">
        <div className="wrap">
          <div className="head"><span className="eyebrow">Services</span><h2>Four ways we can support your campaigns</h2></div>
          <div className="grid g4">
            {[["Guest Posting and Link Building", "Publisher research, outreach and placement coordination for contextual editorial links.", "guest-posting"],
              ["Digital PR", "Campaign angles and outreach aimed at earning relevant editorial coverage.", "digital-pr"],
              ["SaaS Link Building", "Relevant authority-building for B2B software and AI companies.", "saas-link-building"],
              ["AI SEO and LLM Visibility", "Content and authority foundations that may help discoverability in AI-assisted search.", "ai-seo"]].map(([t, d, id]) => (
              <div className="card" key={id}><h3>{t}</h3><p>{d}</p><Link href={`/services#${id}`}>Learn more about {t.split(" and ")[0].toLowerCase()}</Link></div>
            ))}
          </div>
        </div>
      </section>

      <section className="s">
        <div className="wrap split">
          <div>
            <span className="eyebrow">Agency partnership</span>
            <h2>An execution partner for your SEO agency</h2>
            <p>Many agencies have the strategy and the client relationships but need extra capacity for link building and Digital PR. We can take on the research and coordination so your team isn't stretched across every campaign.</p>
            <Link href="/contact" className="btn p">Partner With Rankonic Digital</Link>
          </div>
          <div className="card">
            <ul className="ticks">
              <li>White-label or behind-the-scenes support, where agreed</li>
              <li>Publisher research and outreach</li>
              <li>Campaign coordination and follow-up</li>
              <li>Clear communication about publisher requirements, pricing and deliverables</li>
              <li>Flexible cooperation based on each project's needs</li>
              <li>Respect for your relationship with your own clients</li>
            </ul>
            <p className="note">Capacity, turnaround times and publisher acceptance depend on the project, and we'll be upfront about them before work begins.</p>
          </div>
        </div>
      </section>

      <section className="s alt">
        <div className="wrap split">
          <div className="card">
            <h3>What this can support for SaaS and AI companies</h3>
            <ul className="ticks">
              <li>Relevant editorial links and mentions from industry publications</li>
              <li>Authority signals for product, category and resource pages</li>
              <li>Referral opportunities from sites your buyers actually read</li>
              <li>A stronger footing in conventional and AI-assisted search</li>
            </ul>
          </div>
          <div>
            <span className="eyebrow">SaaS and AI companies</span>
            <h2>Authority-building that fits your wider SEO plan</h2>
            <p>Relevant backlinks and editorial coverage can support a broader organic strategy for software businesses. They work alongside strong content, a sound site and a clear product position.</p>
            <p>Rankings, citations and AI-generated recommendations depend on many factors outside our control, so we plan for steady progress rather than quick wins.</p>
            <Link href="/contact" className="btn p">Discuss Your SaaS SEO Goals</Link>
          </div>
        </div>
      </section>

      <section className="s">
        <div className="wrap">
          <div className="head"><span className="eyebrow">How we work</span><h2>A simple four-step process</h2>
            <p>This is how we usually structure an engagement. We adapt it to each client's needs.</p></div>
          <div className="grid g4">
            {[["Understand the business", "We learn about your goals, audience, target pages and markets."],
              ["Plan the opportunities", "We identify relevant publishers or PR angles and agree the scope with you."],
              ["Coordinate execution", "We run outreach and coordinate placements or PR activity."],
              ["Share progress", "We report on agreed deliverables and where each opportunity stands."]].map(([t, d], i) => (
              <div className="card" key={t}><div className="num">{i + 1}</div><h3>{t}</h3><p>{d}</p></div>))}
          </div>
        </div>
      </section>

      <section className="s alt">
        <div className="wrap">
          <div className="head"><span className="eyebrow">Why Rankonic Digital</span><h2>What you can expect from us</h2></div>
          <div className="grid g3">
            {[["Focus on topical relevance", "We prioritise sites that fit the client's subject and audience."],
              ["Agency-friendly collaboration", "We work the way agencies need: clear briefs, simple handovers, minimal overhead."],
              ["SaaS and B2B understanding", "We understand software buyers, product pages and how SaaS content is built."],
              ["Clear communication", "You'll know what we're doing, what we need from you and what's still open."],
              ["Traditional SEO and AI search", "We treat AI-search visibility as a complement to proven SEO, not a replacement."]].map(([t, d]) => (
              <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>))}
          </div>
        </div>
      </section>

      <section className="s" id="faq">
        <div className="wrap" style={{ maxWidth: 860 }}>
          <div className="head"><span className="eyebrow">FAQ</span><h2>Frequently asked questions</h2></div>
          <Faq items={faqs} />
        </div>
      </section>
      <FinalCta />
      <JsonLd data={{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) }} />
    </>
  );
}
