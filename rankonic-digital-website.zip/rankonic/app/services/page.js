import Link from "next/link";
import { FinalCta } from "../../components/ui";

export const metadata = {
  title: "SEO Link-Building Services: Guest Posting, Digital PR & More | Rankonic Digital",
  description: "Explore Rankonic Digital's guest posting, Digital PR, SaaS link-building and AI SEO services for agencies and software companies. Request a tailored proposal.",
  alternates: { canonical: "/services" },
  openGraph: { title: "SEO Link-Building Services | Rankonic Digital", description: "Guest posting, Digital PR, SaaS link building and AI SEO support.", url: "/services" },
};

const services = [
  { id: "guest-posting", title: "Guest Posting and Link Building",
    intro: "We research relevant publishers, coordinate outreach and manage placements so your content can earn contextual editorial links in the right places.",
    points: ["Publisher research and relevance assessment", "Guest article outreach and placement coordination", "Contextual editorial backlinks, where agreed", "Alignment with the client's niche and target pages", "Attention to editorial standards and natural content"],
    note: "We don't choose publishers on domain authority alone. Not every publisher accepts every request, and we can't guarantee that a placement will be indexed or improve rankings. We tell you each publisher's requirements upfront.", related: ["digital-pr", "saas-link-building"] },
  { id: "digital-pr", title: "Digital PR",
    intro: "Digital PR focuses on earning coverage from publications that suit your story, rather than placing a link yourself.",
    points: ["Campaign and angle development", "Research into relevant publications and journalists", "Outreach coordination", "Editorial opportunities for useful ideas and data", "Brand mentions and links, where publishers independently choose to include them"],
    note: "Editors decide what they publish. We can't guarantee coverage, links or media attention, but we can build campaigns that give your story a fair chance.", related: ["guest-posting", "ai-seo"] },
  { id: "saas-link-building", title: "SaaS Link Building",
    intro: "Link building for B2B software and AI companies, shaped around how SaaS buyers research and how SaaS sites are structured.",
    points: ["Relevant publisher opportunities in your industry", "Support for product, category, feature and resource pages, where appropriate", "Supporting content opportunities", "Topical relevance and natural anchor-text choices", "Coordination with your existing SEO strategy"],
    note: "Links alone won't solve a SaaS company's organic growth challenges. They work best alongside strong content, a sound site and a clear product position.", related: ["guest-posting", "ai-seo"] },
  { id: "ai-seo", title: "AI SEO and LLM Visibility",
    intro: "Work that improves the content, technical foundations, topical clarity and authority signals that may support visibility in AI-assisted search experiences.",
    points: ["Content and topical clarity that machines and people can both understand", "Technical foundations that make a site easy to read and cite", "Authority signals built through relevant mentions and links", "Guidance on how AI-assisted search tools such as ChatGPT, Perplexity, Gemini, Claude and Google's AI experiences may surface sources"],
    note: "We are not affiliated with or endorsed by any AI platform. These systems choose and generate answers in ways we can't control, so no one can guarantee citations or recommendations. A backlink will not directly produce an AI citation. Treat this as a complement to sound SEO, not a replacement.", related: ["digital-pr", "saas-link-building"] },
];
const titleOf = Object.fromEntries(services.map((s) => [s.id, s.title]));

export default function Services() {
  return (
    <>
      <section className="hero"><div className="wrap" style={{ gridTemplateColumns: "1fr" }}>
        <div style={{ maxWidth: 780 }}>
          <span className="eyebrow">Services</span>
          <h1>SEO Link-Building and Digital PR Services</h1>
          <p className="lead">Four focused services for SEO agencies and software companies. Choose the one that fits, or talk to us about combining them.</p>
          <Link href="/contact" className="btn p">Request a Tailored Proposal</Link>
        </div></div></section>

      <div className="wrap">
        {services.map((s) => (
          <section key={s.id} id={s.id} className="svc">
            <div className="split" style={{ alignItems: "start" }}>
              <div><h2>{s.title}</h2><p className="lead">{s.intro}</p>
                <p className="small">Related: {s.related.map((r, i) => <span key={r}>{i ? ", " : ""}<Link href={`/services#${r}`}>{titleOf[r]}</Link></span>)}</p></div>
              <div className="card">
                <h3>What's included</h3>
                <ul className="ticks">{s.points.map((p) => <li key={p}>{p}</li>)}</ul>
                <p className="note">{s.note}</p>
                <Link href="/contact" className="btn p sm">Discuss {s.title.split(" and ")[0]}</Link>
              </div>
            </div>
          </section>
        ))}
        <section className="svc">
          <div className="card"><h2>How pricing works</h2>
            <p>We don't publish fixed packages, because the right scope depends on your target market, publisher criteria, campaign requirements and the deliverables we agree. <Link href="/contact">Send us your requirements</Link> and we'll respond with a tailored proposal.</p></div>
        </section>
      </div>
      <FinalCta title="Not sure which service fits?" text="Describe what you're trying to achieve and we'll suggest a sensible starting point, even if that's a smaller scope than you expected." />
    </>
  );
}
