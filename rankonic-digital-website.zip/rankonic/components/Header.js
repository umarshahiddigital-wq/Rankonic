"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { site } from "../content/site";

export default function Header() {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  useEffect(() => setOpen(false), [path]);
  useEffect(() => {
    const k = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", k);
    return () => document.removeEventListener("keydown", k);
  }, []);
  return (
    <header className="site">
      <div className="wrap bar">
        <Link href="/" className="brand" aria-label="Rankonic Digital home">
          <img src="/logo-mark.png" alt="" width="42" height="46" />
          <img src="/logo-wordmark.png" alt="Rankonic Digital" width="128" height="32" />
        </Link>
        <button className="menu-btn" aria-expanded={open} aria-controls="main-nav" onClick={() => setOpen(!open)}>
          {open ? "Close" : "Menu"}
        </button>
        <nav id="main-nav" className={"main" + (open ? " open" : "")} aria-label="Main">
          {site.nav.map((n) => (
            <Link key={n.href} href={n.href} className="l" aria-current={path === n.href ? "page" : undefined}>{n.label}</Link>
          ))}
          <Link href="/book-a-call" className="btn p sm">Book a Call</Link>
        </nav>
      </div>
    </header>
  );
}
