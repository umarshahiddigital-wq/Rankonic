import Link from "next/link";
import { site, whatsappUrl } from "../content/site";

export function FinalCta({ title = "Ready to talk through your requirements?", text = "Tell us about your clients, your target markets and what you need from a link-building or Digital PR partner. We'll reply with an honest view of whether we're a good fit." }) {
  return (
    <section className="cta">
      <div className="wrap">
        <h2>{title}</h2>
        <p>{text}</p>
        <div className="row">
          <Link href="/contact" className="btn p">Discuss Your Requirements</Link>
          <a href={whatsappUrl} className="btn s" target="_blank" rel="noopener noreferrer">Message on WhatsApp</a>
        </div>
        <p className="small" style={{ marginTop: 18 }}>Or email <a href={`mailto:${site.email}`}>{site.email}</a></p>
      </div>
    </section>
  );
}

export function JsonLd({ data }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

export function Faq({ items }) {
  return items.map(([q, a]) => (
    <details key={q}><summary>{q}</summary><p>{a}</p></details>
  ));
}
