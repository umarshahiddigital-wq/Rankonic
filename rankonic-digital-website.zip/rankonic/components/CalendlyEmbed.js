"use client";
import { useState } from "react";

export default function CalendlyEmbed({ url }) {
  const [show, setShow] = useState(false);
  return (
    <div>
      {!show ? (
        <div className="card">
          <h3>Choose a time that suits you</h3>
          <p>The calendar is provided by Calendly and only loads when you click the button, so no third-party content is loaded until you choose it.</p>
          <div className="row">
            <button className="btn p" onClick={() => setShow(true)}>Load Booking Calendar</button>
            <a className="btn s" href={url} target="_blank" rel="noopener noreferrer">Open in Calendly</a>
          </div>
        </div>
      ) : (
        <iframe title="Book a call with Rankonic Digital" src={url} width="100%" height="700" style={{ border: 0, borderRadius: 14, background: "#fff" }} loading="lazy" />
      )}
    </div>
  );
}
