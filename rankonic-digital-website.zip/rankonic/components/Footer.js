import Link from "next/link";
import { site, whatsappUrl } from "../content/site";

export default function Footer() {
  return (
    <footer className="site">
      <div className="wrap">
        <div className="fgrid">
          <div>
            <img src="/logo-full.png" alt="Rankonic Digital logo" width="150" height="116" style={{ marginBottom: 14 }} />
            <p className="small">Guest posting, link building, Digital PR and AI-search support for SEO agencies and SaaS companies.</p>
          </div>
          <div><h2>Company</h2><ul>
            {site.nav.map((n) => <li key={n.href}><Link href={n.href}>{n.label}</Link></li>)}
            <li><Link href="/book-a-call">Book a Call</Link></li></ul></div>
          <div><h2>Services</h2><ul>
            <li><Link href="/services#guest-posting">Guest Posting and Link Building</Link></li>
            <li><Link href="/services#digital-pr">Digital PR</Link></li>
            <li><Link href="/services#saas-link-building">SaaS Link Building</Link></li>
            <li><Link href="/services#ai-seo">AI SEO and LLM Visibility</Link></li></ul></div>
          <div><h2>Get in touch</h2><ul>
            <li><a href={`mailto:${site.email}`}>{site.email}</a></li>
            <li><a href={whatsappUrl} target="_blank" rel="noopener noreferrer">WhatsApp: {site.whatsappDisplay}</a></li>
            <li><Link href="/privacy">Privacy Policy</Link></li></ul></div>
        </div>
        <p className="copy">© {new Date().getFullYear()} Rankonic Digital. All rights reserved.</p>
      </div>
    </footer>
  );
}
