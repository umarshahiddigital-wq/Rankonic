"use client";
import { useState } from "react";
import Link from "next/link";
import { serviceOptions, budgetOptions, site } from "../content/site";

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validate(v) {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Please enter your full name.";
  if (!emailRe.test(v.email.trim())) e.email = "Please enter a valid business email address.";
  if (v.company.trim().length < 2) e.company = "Please enter your company name or website.";
  if (!serviceOptions.includes(v.service)) e.service = "Please choose a service.";
  if (v.message.trim().length < 20) e.message = "Please describe your requirements in at least 20 characters.";
  return e;
}

export default function ContactForm() {
  const [v, setV] = useState({ name: "", email: "", company: "", service: "", budget: "Not sure yet", message: "", hp: "" });
  const [errors, setErrors] = useState({});
  const [state, setState] = useState("idle"); // idle | sending | success | error
  const [serverMsg, setServerMsg] = useState("");
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    const errs = validate(v);
    setErrors(errs);
    if (Object.keys(errs).length) { document.getElementById(`f-${Object.keys(errs)[0]}`)?.focus(); return; }
    setState("sending");
    try {
      const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(v) });
      const d = await r.json().catch(() => ({}));
      if (r.ok && d.ok) setState("success");
      else { setServerMsg(d.error || "Something went wrong."); setState("error"); }
    } catch { setServerMsg("We couldn't reach the server."); setState("error"); }
  }

  if (state === "success")
    return <div className="alert ok" role="status"><strong>Thank you, your inquiry has been sent.</strong><br />We'll review your requirements and reply by email.</div>;

  const F = ({ id, label, children }) => (
    <div className="f"><label htmlFor={`f-${id}`}>{label}</label>{children}
      {errors[id] && <p className="err" id={`e-${id}`}>{errors[id]}</p>}</div>
  );
  const a = (id) => ({ id: `f-${id}`, "aria-invalid": !!errors[id], "aria-describedby": errors[id] ? `e-${id}` : undefined });

  return (
    <form onSubmit={submit} noValidate>
      {state === "error" && (
        <div className="alert bad" role="alert"><strong>Your message was not sent.</strong> {serverMsg}<br />
          Please email us directly at <a href={`mailto:${site.email}`}>{site.email}</a>.</div>
      )}
      <F id="name" label="Full name *"><input {...a("name")} value={v.name} onChange={set("name")} autoComplete="name" required /></F>
      <F id="email" label="Business email *"><input {...a("email")} type="email" value={v.email} onChange={set("email")} autoComplete="email" required /></F>
      <F id="company" label="Company or website *"><input {...a("company")} value={v.company} onChange={set("company")} autoComplete="organization" required /></F>
      <F id="service" label="Service of interest *">
        <select {...a("service")} value={v.service} onChange={set("service")} required>
          <option value="">Select a service</option>{serviceOptions.map((o) => <option key={o}>{o}</option>)}</select></F>
      <F id="budget" label="Approximate budget (optional)">
        <select id="f-budget" value={v.budget} onChange={set("budget")}>{budgetOptions.map((o) => <option key={o}>{o}</option>)}</select></F>
      <F id="message" label="Brief project requirements *"><textarea {...a("message")} rows={6} value={v.message} onChange={set("message")} required /></F>
      <div className="hp" aria-hidden="true"><label>Leave empty<input tabIndex={-1} autoComplete="off" value={v.hp} onChange={set("hp")} /></label></div>
      <button className="btn p" type="submit" disabled={state === "sending"}>{state === "sending" ? "Sending…" : "Send Inquiry"}</button>
      <p className="small" style={{ marginTop: 14 }}>We use these details only to reply to your inquiry. See our <Link href="/privacy">privacy policy</Link>.</p>
    </form>
  );
}
