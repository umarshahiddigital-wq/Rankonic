// EDIT THIS FILE to change contact details, links and the Calendly URL. Page wording lives in the files under /app.
export const site = {
  name: "Rankonic Digital",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://YOUR-DOMAIN.com",
  email: "umarshahid.digital@gmail.com",
  whatsappDisplay: "03214357247",
  whatsappIntl: "923214357247", // Pakistan +92, leading zero removed
  whatsappMessage: "Hi Rankonic Digital, I'd like to discuss your SEO and link-building services.",
  calendlyUrl: "YOUR_CALENDLY_URL_HERE", // replace with your real https://calendly.com/... link
  founder: "Umar Shahid",
  nav: [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
  ],
};
export const whatsappUrl = `https://wa.me/${site.whatsappIntl}?text=${encodeURIComponent(site.whatsappMessage)}`;
export const calendlyReady = /^https:\/\/(www\.)?calendly\.com\//.test(site.calendlyUrl);
export const serviceOptions = [
  "Guest Posting and Link Building", "Digital PR", "SaaS Link Building",
  "AI SEO and LLM Visibility", "White-label or agency partnership", "Other",
];
export const budgetOptions = ["Not sure yet", "Under $500", "$500 – $1,500", "$1,500 – $5,000", "$5,000+"];
